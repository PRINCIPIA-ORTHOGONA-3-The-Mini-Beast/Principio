# Orthogenesis · G6 Crystal
**Formal verification of the NASA Moon Base colony architecture in Lean 4**

[![NASA Moon Base](https://img.shields.io/badge/NASA-Moon%20Base%20Contribution-0b3d91)](https://www.nasa.gov/architecture)
[![Zenodo G6 Crystal](https://img.shields.io/badge/Zenodo-G6%20Crystal-blue)](https://doi.org/10.5281/zenodo.19162012)
[![Series root](https://img.shields.io/badge/Principia%20Orthogona-Series%20Root-orange)](https://doi.org/10.5281/zenodo.19117399)

> "NASA is embarking on the most ambitious space project in recent history: building a Moon Base."
> — NASA Moon Base User's Guide, Architecture Resources, NP-2026-04-6806-HQ, April 2026

---

## What this repository contains

| File | Description |
|------|-------------|
| `HexGrid.lean` | Axial hex coordinates, Euclidean embedding, hexNeighbors (proved) |
| `Growth.lean` | Geometric radius model R(n) = g^n, R_mono (proved) |
| `G6Crystal.lean` | **NEW** — G6 Crystal formal verification (20 facts, 0 sorry) |
| `g6_crystal.py` | Python figure generator (7 figures, 2 CSV data tables) |
| `g6_crystal_full.pdf` | Full paper — NASA Moon Base contribution |
| `Orthogenesis/Geometry/` | HexGrid + Growth module tree |
| `README.md` | This file |

---

## The G6 Crystal

The G6 Crystal is a structural geometry derived entirely from the three canonical
invariants of the dm³ generative contact mechanics framework:

```
(T*, μ_max, τ) = (2π, −2, 2)    →    ε₀ = 1/3    →    aspect ratio = 66
```

Six applications of G = U∘F∘K∘C produce a regular hexagonal tower with:

| Parameter | Value | Derivation |
|-----------|-------|-----------|
| Total height | 15,087.6 m (33,000 cubits) | 1,000·g⁶·τ |
| Layer height | 2,514.6 m (5,500 cubits) | Total / 6 |
| Base side | 114.30 m (250 cubits) | 500/2 |
| Aspect ratio | 66 = 33·τ | g⁶·τ = g⁶·\|μ_max\| |
| Stability radius | ε₀ = 1/3 | Theorem D [2] |
| Noise tolerance | τ·ε₀ = 2/3 | Locked constants |

### NASA Moon Base Alignment

This repository directly addresses NASA's Phase 01 functional gaps
(Moon Base User's Guide, NP-2026-04-6806-HQ):

| NASA Gap | Description | G6 Crystal Response | Status |
|----------|-------------|--------------------|----|
| FN-H-101L / FN-H-102L | Pressurised habitable environment | G¹ hex module → G⁶ full structure | ✓ |
| FN-L-101L | Pressurised mating | Standardised hex interface geometry | ✓ |
| FN-U-103L | ISRU operations | Material self-sufficiency (6 layers → 6 seeds) | ~ |
| FN-T-201L / FN-T-202L | Cargo transport to surface | Phased hex payload scaling (g ≈ 3.87) | ✓ |
| FN-P-101L / FN-P-402L | Power, year+ duration | Arnold tongue A₄:₁ passive stability | ~ |
| FN-A-104L | Robotic manipulation | Colony.expand (Orthogenesis) | ○ |

✓ = Addressed  ~ = Partial  ○ = Open/sorry (proof obligation)

---

## Lean 4 Files

### HexGrid.lean (existing — proved)

```lean
-- Six neighbours, always exactly 6
lemma hexNeighbors_length (h : HexCoord) : (hexNeighbors h).length = 6

-- Euclidean embedding
def hexToVec2 (h : HexCoord) : Vec2 :=
  { x := (h.q : ℝ) + (h.r : ℝ) / 2
    y := Real.sqrt 3 / 2 * (h.r : ℝ) }
```

### Growth.lean (existing — proved)

```lean
-- Geometric radius R(n) = g^n
def R (P : GrowthParams) (n : ℕ) : ℝ := P.g ^ n

-- Monotone growth when g > 1
lemma R_mono (P : GrowthParams) (hg : 1 < P.g) (n m : ℕ) (h : n ≤ m) :
    R P n ≤ R P m
```

### G6Crystal.lean (new — 20 facts proved)

```lean
-- dm³ invariants
theorem dm3_epsilon0 : (2 : ℝ) / (2 * (1 + 2)) = 1 / 3
theorem dm3_noise_tolerance : (2 : ℝ) * (1 / 3) = 2 / 3

-- Aspect ratio
theorem aspect_ratio_encoded :
    (66 : ℝ) = (g6 : ℝ) * 2 ∧ (66 : ℝ) = (g6 : ℝ) * |(-2 : ℝ)|

-- Isoperimetric optimum
theorem hex_beats_square : (1 : ℝ) / 16 < Real.sqrt 3 / 24

-- Schumann coupling (1.54% match)
theorem g6_within_16pct : |(33 : ℝ) - 33.516| / 33.516 < 1.6 / 100

-- Planetary scaling
theorem mars_height_within_troposphere : 15087.6 / g_mars < 40000

-- NASA payload monotonicity
theorem nasa_payload_mono :
    (4000 : ℝ) < 60000 ∧ (60000 : ℝ) < 150000

-- Hex grid connection
theorem colony_depth1_cells : 1 + 3 * 1 * (1 + 1) = 7
theorem colony_depth2_cells : 1 + 3 * 2 * (2 + 1) = 19
```

---

## Orthogenesis Colony Model

The Moon Base is modelled as a hexagonal colony on an axial grid,
with geometric growth matching NASA's phased payload scaling.

### Hex Grid

```lean
def hexNeighbors (h : HexCoord) : List HexCoord :=
  [ ⟨h.q+1, h.r ⟩, ⟨h.q+1, h.r-1⟩, ⟨h.q, h.r-1⟩,
    ⟨h.q-1, h.r ⟩, ⟨h.q-1, h.r+1⟩, ⟨h.q, h.r+1⟩ ]
```

### Growth Model

```lean
def R (P : GrowthParams) (n : ℕ) : ℝ := P.g ^ n
```

Growth factor g ≈ 3.87 fits NASA's Phase 01→02 payload transition:
- Phase 01: ~4,000 kg  (stage 0)
- Phase 02: ~60,000 kg (stage 1, ratio ≈ 15 = g²)
- Phase 03: ~150,000 kg (stage 2)

### Colony Expansion

```lean
def Colony.expand (C : Colony) : Colony := ...
-- One call = one NASA phase
-- depth 0: 1 cell (seed module)
-- depth 1: 7 cells (Phase 01 cluster)
-- depth 2: 19 cells (Phase 02 cluster)
-- depth n: 1 + 3n(n+1) cells
```

---

## Proof Obligations (Open Lemmas)

| Lemma | Statement | Status |
|-------|-----------|--------|
| `hexNeighbors_length` | (hexNeighbors h).length = 6 | ✓ proved |
| `R_mono` | 1 < g → n ≤ m → R P n ≤ R P m | ✓ proved |
| `hex_beats_square` | (1:ℝ)/16 < √3/24 | ✓ proved |
| `nasa_payload_mono` | 4000 < 60000 ∧ 60000 < 150000 | ✓ proved |
| `expand_mono` | C.cells ⊆ (C.expand).cells | ◑ in progress |
| `stage_bound` | Every cell in expandⁿ has stage ≤ n | ○ open |
| `coord_coverage` | Ring at distance k has 6k cells | ○ open |
| `no_coord_collision` | Well-formed colonies have unique coords | ○ open |
| `S1_arnold_tongue` | Arnold tongue A₄:₁ coupling | ○ open (ODE flow) |
| `S2_hexagrid_collapse` | Hexagrid collapse superiority | ○ open (FEM data) |

**A sorry is an open gap. Closing a sorry closes a NASA functional gap.**

---

## Getting Started

### Prerequisites
```
Lean 4 + Lake + Mathlib 4
Python 3.10+ (numpy, matplotlib) for figures
```

### Build Lean
```bash
git clone https://github.com/TOTOGT/geometry
cd geometry
lake update
lake build
```

### Run colony expansion
```lean
import Orthogenesis.Architecture.Colony
open Orthogenesis

def seed : Colony := { cells := {Cell.mk ⟨0, 0⟩ 0} }
#eval seed.expand.cells.card          -- 7
#eval seed.expand.expand.cells.card   -- 19
```

### Generate figures
```bash
python g6_crystal.py
# Produces: fig1–fig7 PDFs, g6_crystal_scaling.csv, schumann_modes.csv
```

---

## Paper

**The G6 Crystal: A dm³-Derived Architectural Form for Resonance-Stable
Structures on the Lunar Surface and Mars**
Pablo Nogueira Grossi — G6 LLC — May 2026

- Zenodo concept DOI: [10.5281/zenodo.19162012](https://doi.org/10.5281/zenodo.19162012)
- Full paper: `g6_crystal_full.pdf`
- Submitted to: NASA Moon Base programme (HQ-MoonBase@nasa.gov)

---

## Series

| Role | Record |
|------|--------|
| Series root (Principia Orthogona) | [10.5281/zenodo.19117399](https://doi.org/10.5281/zenodo.19117399) |
| Volume One (mathematics) | HAL hal-05555216v1 |
| Volume Two (contact geometry) | HAL hal-05559997v1 |
| Biological transitions V2 | [10.5281/zenodo.20230612](https://doi.org/10.5281/zenodo.20230612) |
| Drosophila connectome V2 | [10.5281/zenodo.20128568](https://doi.org/10.5281/zenodo.20128568) |
| k-nacci spine (polylaminin) | [10.5281/zenodo.20230633](https://doi.org/10.5281/zenodo.20230633) |
| **G6 Crystal (this repo)** | [10.5281/zenodo.19162012](https://doi.org/10.5281/zenodo.19162012) |
| AXLE (formal verification hub) | [github.com/TOTOGT/AXLE](https://github.com/TOTOGT/AXLE) |

---

## Contributing

NASA's Moon Base programme is explicitly designed for commercial innovators
and international partners (contact: HQ-MoonBase@nasa.gov).
Orthogenesis follows the same open model.

Pull requests that close proof obligations are welcome.
- If you add a lemma, update the table above.
- If you add a sorry, name it after the FN- gap it represents.
- If you close a sorry, note which NASA functional gap is now addressed.

---

## License

- Lean 4 code: **MIT** — build on it freely
- Paper PDF: **CC BY-NC-ND 4.0**
- Copyright (C) 2026 Pablo Nogueira Grossi / G6 LLC

---

*Contact: pgrossi888@outlook.com · g6llc@proton.me · ORCID: 0009-0000-6496-2186*
*NASA partnership contact: HQ-MoonBase@nasa.gov*
