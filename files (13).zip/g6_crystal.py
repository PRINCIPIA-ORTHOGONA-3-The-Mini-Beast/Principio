"""
g6_crystal.py
=============
Figure generator + computation engine for:
  "The G6 Crystal: A dm³-Derived Architectural Form
   for Resonance-Stable Structures on the Lunar Surface and Mars"
  Pablo Nogueira Grossi — G6 LLC — May 2026

Produces 7 figures + CSV data tables.
All constants derived from dm³ invariants (T*=2π, μ_max=−2, τ=2).
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.patheffects as pe
from matplotlib.patches import RegularPolygon, FancyArrowPatch, Wedge
from matplotlib.lines import Line2D
import os, csv, math

OUT = "/mnt/user-data/outputs"

# ── DejaVu fonts for consistency with Lean/PDF stack ──────────────────────────
plt.rcParams.update({
    "font.family":       "DejaVu Serif",
    "font.size":         10,
    "axes.facecolor":    "#0d1117",
    "figure.facecolor":  "#0d1117",
    "axes.edgecolor":    "#2a3a4a",
    "axes.labelcolor":   "#e0e8f0",
    "axes.titlecolor":   "#e0e8f0",
    "xtick.color":       "#7a8fa6",
    "ytick.color":       "#7a8fa6",
    "grid.color":        "#1e2d3d",
    "grid.linewidth":    0.5,
    "text.color":        "#e0e8f0",
    "savefig.dpi":       200,
    "savefig.bbox":      "tight",
    "savefig.facecolor": "#0d1117",
})

# ── Palette ───────────────────────────────────────────────────────────────────
C = {
    "gold":   "#f0c040",
    "blue":   "#4fc3f7",
    "green":  "#81c784",
    "red":    "#ef9a9a",
    "violet": "#ce93d8",
    "orange": "#ffb74d",
    "teal":   "#4dd0e1",
    "white":  "#e0e8f0",
    "dim":    "#7a8fa6",
    "bg":     "#0d1117",
    "panel":  "#111d2b",
    "border": "#2a3a4a",
}

# ── dm³ Constants ─────────────────────────────────────────────────────────────
T_STAR   = 2 * np.pi        # 2π
MU_MAX   = -2.0
TAU      = 2.0
EPS0     = 1/3              # stability radius
G6_INT   = 33               # Schumann coupling integer
SCHUMANN_N4 = 33.516        # Hz, theoretical

# ── G6 Crystal dimensions ─────────────────────────────────────────────────────
CUBIT_M       = 0.4572      # common cubit in metres
TOTAL_H_CUB   = 33_000      # cubits
BASE_W_CUB    = 500         # cubits (characteristic width)
BASE_S_CUB    = 250         # cubits (hexagon side)
N_LAYERS      = 6

TOTAL_H_M  = TOTAL_H_CUB * CUBIT_M          # 15,087.6 m
BASE_S_M   = BASE_S_CUB  * CUBIT_M          # 114.30 m
LAYER_H_M  = TOTAL_H_M / N_LAYERS           # 2,514.6 m
ASPECT     = TOTAL_H_CUB / BASE_W_CUB       # 66

# ── Planetary parameters ──────────────────────────────────────────────────────
PLANETS = {
    "Earth": {"g": 9.81,  "color": C["blue"],   "marker": "o"},
    "Moon":  {"g": 1.625, "color": C["dim"],     "marker": "s"},
    "Mars":  {"g": 3.721, "color": C["red"],     "marker": "^"},
}
G_EARTH = PLANETS["Earth"]["g"]

def scaled_height(g_planet):
    return TOTAL_H_M * G_EARTH / g_planet

def scaled_base(g_planet):
    return BASE_S_M * G_EARTH / g_planet

# ═══════════════════════════════════════════════════════════════════════════════
# Fig 1 — Operator hierarchy G⁰→G⁶ with layer dimensions
# ═══════════════════════════════════════════════════════════════════════════════
def fig1_operator_hierarchy():
    fig, ax = plt.subplots(figsize=(8, 10))
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.5, 7.5)
    ax.axis("off")

    layer_colors = [C["teal"], C["blue"], C["green"],
                    C["gold"], C["orange"], C["violet"], C["red"]]
    operators    = ["C", "K", "F", "U", "C", "K", "F·U"]
    op_labels    = [
        "Compress", "Curvature", "Fold", "Stabilise",
        "Compress", "Curvature", "Fold·Stabilise"
    ]

    box_w = 5.0
    heights_m = [LAYER_H_M * i for i in range(N_LAYERS + 1)]

    for i in range(N_LAYERS + 1):
        y   = i
        col = layer_colors[i]
        # layer box
        rect = mpatches.FancyBboxPatch(
            (2.5, y - 0.38), box_w, 0.76,
            boxstyle="round,pad=0.05",
            linewidth=1.4, edgecolor=col,
            facecolor=col + "22",
        )
        ax.add_patch(rect)

        # Layer label
        lbl = f"G⁰" if i == 0 else f"G{i}"
        ax.text(2.8, y, lbl, va="center", ha="left",
                fontsize=13, fontweight="bold", color=col)

        # Height annotation
        h_m   = heights_m[i]
        h_cub = int(h_m / CUBIT_M)
        ax.text(7.3, y, f"{h_m:,.0f} m\n({h_cub:,} cubits)",
                va="center", ha="left", fontsize=8, color=C["dim"])

        # Operator label (between layers)
        if i < N_LAYERS:
            op = operators[i]
            op_lbl = op_labels[i]
            ax.text(5.0, y + 0.5,
                    f"─── {op}: {op_lbl} ───",
                    va="center", ha="center", fontsize=7.5,
                    color=C["dim"], style="italic")

    # Ground line
    ax.axhline(-0.1, xmin=0.25, xmax=0.95,
               color=C["border"], linewidth=1)
    ax.text(5.0, -0.4, "Ground level  (0 m)",
            ha="center", va="center", fontsize=8, color=C["dim"])

    # Tropopause annotation
    ax.axhline(6.0, xmin=0.25, xmax=0.95,
               color=C["orange"], linewidth=0.8, linestyle="--", alpha=0.6)
    ax.text(7.4, 6.3, "Tropopause\n≈ 15 km",
            ha="left", va="center", fontsize=7.5, color=C["orange"])

    ax.set_title(
        "Fig 1 — G6 Crystal: Operator Hierarchy G⁰ → G⁶\n"
        "Six applications of G = U∘F∘K∘C, each producing one structural layer",
        pad=10, fontsize=11, color=C["white"])

    fig.tight_layout()
    path = os.path.join(OUT, "fig1_operator_hierarchy.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# Fig 2 — Hexagonal cross-section + isoperimetric comparison
# ═══════════════════════════════════════════════════════════════════════════════
def fig2_hexagonal_geometry():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

    # ── Left: hexagon cross-section ──────────────────────────────────────────
    ax1.set_aspect("equal")
    ax1.set_facecolor(C["bg"])

    s = BASE_S_M  # 114.30 m
    # Hexagon vertices (flat-top orientation)
    angles = np.linspace(0, 2*np.pi, 7)
    hx = s * np.cos(angles + np.pi/6)
    hy = s * np.sin(angles + np.pi/6)
    ax1.fill(hx, hy, color=C["blue"] + "22", linewidth=0)
    ax1.plot(hx, hy, color=C["blue"], linewidth=2.0)

    # Inradius
    inrad = s * np.sqrt(3) / 2  # 98.99 m
    ax1.plot([0, inrad], [0, 0], color=C["gold"],
             linewidth=1.5, linestyle="--")
    ax1.text(inrad/2, 4, f"r = {inrad:.2f} m",
             ha="center", color=C["gold"], fontsize=8.5)

    # Side label
    ax1.plot([hx[0], hx[1]], [hy[0], hy[1]],
             color=C["orange"], linewidth=2.5)
    mx, my = (hx[0]+hx[1])/2, (hy[0]+hy[1])/2
    ax1.annotate(f"s = {s:.2f} m",
                 xy=(mx, my), xytext=(mx + 30, my + 30),
                 arrowprops=dict(arrowstyle="->", color=C["orange"], lw=1),
                 color=C["orange"], fontsize=8.5)

    # Area annotation
    area = 3*np.sqrt(3)/2 * s**2
    ax1.text(0, -s*0.7, f"A = {area:,.0f} m²\nP = {6*s:,.0f} m",
             ha="center", color=C["dim"], fontsize=8.5)

    ax1.set_xlim(-s*1.3, s*1.8)
    ax1.set_ylim(-s*1.1, s*1.1)
    ax1.axis("off")
    ax1.set_title("Cross-section\n(regular hexagon, side 114.30 m)",
                  color=C["white"], fontsize=10)

    # ── Right: A/P² vs n-gon ─────────────────────────────────────────────────
    ax2.set_facecolor(C["bg"])
    ns = np.arange(3, 25)
    ratios = np.array([1/(4*n) * (1/np.tan(np.pi/n)) for n in ns])
    circle_ratio = 1 / (4 * np.pi)

    ax2.plot(ns, ratios, color=C["blue"], linewidth=2.0,
             marker="o", markersize=4, label="Regular n-gon")
    ax2.axhline(circle_ratio, color=C["dim"], linestyle=":",
                linewidth=1.2, label=f"Circle: 1/4π ≈ {circle_ratio:.4f}")

    # Highlight hexagon
    hex_idx = 3  # n=6 is index 3
    ax2.scatter([6], [ratios[hex_idx]],
                color=C["gold"], s=120, zorder=5,
                label=f"Hexagon (n=6): {ratios[hex_idx]:.5f}")
    ax2.annotate("Hexagon\n+15.47% vs square",
                 xy=(6, ratios[hex_idx]),
                 xytext=(10, ratios[hex_idx] - 0.003),
                 arrowprops=dict(arrowstyle="->", color=C["gold"], lw=1),
                 color=C["gold"], fontsize=8.5)

    # Highlight square
    sq_idx = 1  # n=4
    ax2.scatter([4], [ratios[sq_idx]],
                color=C["red"], s=80, zorder=5,
                label=f"Square (n=4): {ratios[sq_idx]:.5f}")

    ax2.set_xlabel("Number of sides n", color=C["dim"])
    ax2.set_ylabel("Isoperimetric ratio A/P²", color=C["dim"])
    ax2.set_title("Isoperimetric Efficiency\nA/P² for regular n-gons",
                  color=C["white"], fontsize=10)
    ax2.legend(loc="lower right", fontsize=8, framealpha=0.2,
               edgecolor=C["border"])
    ax2.grid(True)
    ax2.set_xlim(2.5, 25)

    fig.suptitle(
        "Fig 2 — G6 Crystal Geometry: Hexagonal Cross-Section and Isoperimetric Optimum",
        fontsize=11, color=C["white"], y=1.01)
    fig.tight_layout()
    path = os.path.join(OUT, "fig2_hexagonal_geometry.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# Fig 3 — Arnold tongue A₄:₁ stability diagram
# ═══════════════════════════════════════════════════════════════════════════════
def fig3_arnold_tongue():
    fig, ax = plt.subplots(figsize=(8, 5.5))

    # Frequency axis
    freqs = np.linspace(25, 42, 500)
    f4    = SCHUMANN_N4  # 33.516 Hz

    # Arnold tongue A4:1: width = τ·ε₀ = 2/3 of eigenmode amplitude
    # Tongue opens as |f - f4| decreases
    noise_tol = TAU * EPS0  # 2/3
    tongue_hw = noise_tol * 0.5  # half-width at resonance
    tongue_width = np.where(
        np.abs(freqs - f4) < 2.0,
        tongue_hw * np.sqrt(np.maximum(0, 1 - ((freqs - f4)/2.0)**2)),
        0.0
    )

    # Stable locked region
    ax.fill_between(freqs,
                    -tongue_width, tongue_width,
                    color=C["green"], alpha=0.35, label="Arnold tongue A₄:₁\n(resonance-locked region)")

    # Boundary lines
    ax.plot(freqs,  tongue_width, color=C["green"], linewidth=1.5, alpha=0.8)
    ax.plot(freqs, -tongue_width, color=C["green"], linewidth=1.5, alpha=0.8)

    # Schumann modes
    c      = 3e8
    R_earth = 6.371e6
    for n in range(1, 7):
        fn = c / (2 * np.pi * R_earth) * np.sqrt(n * (n + 1))
        lc = C["gold"] if n == 4 else C["dim"]
        lw = 2.0 if n == 4 else 0.8
        ax.axvline(fn, color=lc, linewidth=lw,
                   linestyle="-" if n == 4 else "--", alpha=0.9)
        ax.text(fn + 0.1, 0.62, f"f{n}={fn:.1f}Hz",
                color=lc, fontsize=7.5 if n != 4 else 8.5,
                rotation=90, va="top")

    # g6=33 marker
    ax.axvline(33.0, color=C["orange"], linewidth=1.8, linestyle=":",
               alpha=0.9, label=f"g⁶ = 33  (1.54% from f₄)")
    ax.text(32.6, 0.55, "g⁶=33", color=C["orange"], fontsize=8.5,
            rotation=90, va="top")

    # Noise tolerance band
    ax.axhline(noise_tol, color=C["violet"], linewidth=1.2,
               linestyle="--", alpha=0.8,
               label=f"Noise tolerance τ·ε₀ = 2/3 ≈ {noise_tol:.3f}")
    ax.axhline(-noise_tol, color=C["violet"], linewidth=1.2,
               linestyle="--", alpha=0.8)

    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Perturbation amplitude")
    ax.set_title(
        "Fig 3 — Arnold Tongue A₄:₁ Resonance Coupling\n"
        "G6 Crystal passive coupling to Schumann n=4 mode (f₄=33.516 Hz)",
        pad=10, fontsize=11)
    ax.legend(loc="upper right", fontsize=8.5, framealpha=0.2,
              edgecolor=C["border"])
    ax.set_xlim(25, 42)
    ax.set_ylim(-0.75, 0.85)
    ax.grid(True)

    fig.tight_layout()
    path = os.path.join(OUT, "fig3_arnold_tongue.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# Fig 4 — Hexagrid vs diagrid structural comparison
# ═══════════════════════════════════════════════════════════════════════════════
def fig4_structural_comparison():
    fig, ax = plt.subplots(figsize=(9, 5.5))

    metrics = [
        "Progressive\ncollapse resistance",
        "Seismic energy\ndissipation",
        "Height\npotential",
        "Material\nefficiency",
        "Lateral\nstiffness",
    ]
    # Normalised scores (hexagrid=100 baseline, diagrid relative)
    # Based on Mashhadiali [4], Scaramozzino [7], Yıldırım [8]
    hexagrid_scores = [100, 100, 100, 100,  75]
    diagrid_scores  = [ 70,  80,  80,  95, 100]
    tubular_scores  = [ 60,  65,  65,  80,  85]

    x     = np.arange(len(metrics))
    width = 0.25

    bars_h = ax.bar(x - width,   hexagrid_scores, width,
                    color=C["gold"],   alpha=0.85, label="Hexagrid (G6 Crystal)")
    bars_d = ax.bar(x,             diagrid_scores,  width,
                    color=C["blue"],   alpha=0.85, label="Diagrid")
    bars_t = ax.bar(x + width,    tubular_scores,  width,
                    color=C["dim"],    alpha=0.75, label="Tubular framed-tube")

    # Value labels
    for bars, col in [(bars_h, C["gold"]), (bars_d, C["blue"]), (bars_t, C["dim"])]:
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, h + 1,
                    str(int(h)), ha="center", va="bottom",
                    fontsize=7.5, color=col)

    # G6 Crystal advantage note
    ax.annotate("Hexagrid\nsuperior",
                xy=(0 - width, 100), xytext=(-0.6, 108),
                arrowprops=dict(arrowstyle="->", color=C["gold"], lw=1.0),
                color=C["gold"], fontsize=8)

    ax.set_xlabel("Performance metric")
    ax.set_ylabel("Relative score (hexagrid = 100 baseline)")
    ax.set_title(
        "Fig 4 — Structural System Comparison\n"
        "Hexagrid vs Diagrid vs Tubular  [Mashhadiali 2013, Scaramozzino 2021, Yıldırım 2024]",
        pad=10, fontsize=11)
    ax.set_xticks(x)
    ax.set_xticklabels(metrics, fontsize=9)
    ax.set_ylim(0, 120)
    ax.legend(loc="upper right", fontsize=9, framealpha=0.2,
              edgecolor=C["border"])
    ax.grid(True, axis="y", alpha=0.4)

    # Source note
    ax.text(0.01, 0.01, "Source: [4,5,7,8]  ★ Lateral stiffness: hexagrid lower than diagrid; "
            "irrelevant for supertall structures where ductility dominates.",
            transform=ax.transAxes, fontsize=6.5, color=C["dim"],
            va="bottom")

    fig.tight_layout()
    path = os.path.join(OUT, "fig4_structural_comparison.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# Fig 5 — Lunar South Pole site + Phase 01 hex module footprint
# ═══════════════════════════════════════════════════════════════════════════════
def fig5_lunar_site():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

    # ── Left: Schematic South Pole site map ───────────────────────────────────
    ax1.set_facecolor(C["bg"])
    ax1.set_aspect("equal")
    ax1.set_xlim(-200, 200)
    ax1.set_ylim(-200, 200)

    # Shackleton Crater (21 km diameter, schematic)
    shackleton = plt.Circle((30, -20), 80, fill=False,
                             edgecolor=C["dim"], linewidth=1.5,
                             linestyle="--")
    ax1.add_patch(shackleton)
    ax1.text(30, -110, "Shackleton\nCrater\n(21 km dia.)",
             ha="center", color=C["dim"], fontsize=7.5)

    # Permanently illuminated zone (Shackleton rim)
    rim_arc = Wedge((30, -20), 85, 30, 150,
                    width=12, color=C["gold"] + "55",
                    linewidth=0)
    ax1.add_patch(rim_arc)
    ax1.text(30, 75, "Near-permanent\nillumination zone\n(rim)",
             ha="center", color=C["gold"], fontsize=7.5)

    # Phase 01 hex module (19m side, scaled)
    module_s = 19.05  # metres (1/6 of full base)
    ph01_x, ph01_y = -80, 60
    hex_angles = np.linspace(0, 2*np.pi, 7)
    mx = module_s * np.cos(hex_angles + np.pi/6) + ph01_x
    my = module_s * np.sin(hex_angles + np.pi/6) + ph01_y
    ax1.fill(mx, my, color=C["blue"] + "44")
    ax1.plot(mx, my, color=C["blue"], linewidth=2.0)
    ax1.text(ph01_x, ph01_y, "G¹\nPhase 01\nmodule",
             ha="center", va="center", color=C["blue"], fontsize=7,
             fontweight="bold")

    # Phase 03 cluster (7-cell honeycomb)
    cluster_cx, cluster_cy = 80, 60
    cluster_s = 8.0
    offsets = [(0,0), (1,0), (0,1), (-1,1), (-1,0), (0,-1), (1,-1)]
    for (q, r) in offsets:
        cx2 = cluster_cx + cluster_s * np.sqrt(3) * (q + r/2)
        cy2 = cluster_cy + cluster_s * 1.5 * r
        ha2 = np.linspace(0, 2*np.pi, 7)
        hx2 = cluster_s * 0.95 * np.cos(ha2 + np.pi/6) + cx2
        hy2 = cluster_s * 0.95 * np.sin(ha2 + np.pi/6) + cy2
        col2 = C["gold"] if (q, r) == (0, 0) else C["green"]
        ax1.fill(hx2, hy2, color=col2 + "44")
        ax1.plot(hx2, hy2, color=col2, linewidth=1.2)
    ax1.text(cluster_cx, cluster_cy + cluster_s*3.5,
             "Phase 03\n7-cell cluster\n(G⁶ honeycomb)",
             ha="center", color=C["green"], fontsize=7)

    # South Pole marker
    ax1.plot(0, 0, "w+", markersize=14, markeredgewidth=2)
    ax1.text(5, -12, "South Pole\n(90°S)",
             color=C["white"], fontsize=7.5)

    # Scale bar
    ax1.plot([-180, -130], [-180, -180], color=C["white"], linewidth=2)
    ax1.text(-155, -175, "50 km", ha="center", color=C["white"], fontsize=7)

    ax1.set_title("Lunar South Pole — Site Schematic\n"
                  "G6 Crystal Phase 01 module and Phase 03 cluster",
                  color=C["white"], fontsize=10)
    ax1.axis("off")

    # ── Right: Phase 01 module dimensions ─────────────────────────────────────
    ax2.set_facecolor(C["bg"])
    ax2.set_aspect("equal")
    ax2.set_xlim(-30, 30)
    ax2.set_ylim(-25, 30)

    # Full G6 Crystal outline (scaled down)
    full_s = 24.0  # display units
    fa = np.linspace(0, 2*np.pi, 7)
    fx = full_s * np.cos(fa + np.pi/6)
    fy = full_s * np.sin(fa + np.pi/6)
    ax2.fill(fx, fy, color=C["dim"] + "22")
    ax2.plot(fx, fy, color=C["dim"], linewidth=1.0, linestyle=":")
    ax2.text(0, -full_s*0.75, f"Full G⁶ Crystal\n{BASE_S_M:.1f} m side",
             ha="center", color=C["dim"], fontsize=7.5)

    # Phase 01 module (1/6 of base)
    ph01_s = full_s / 6
    pa = np.linspace(0, 2*np.pi, 7)
    px = ph01_s * np.cos(pa + np.pi/6)
    py = ph01_s * np.sin(pa + np.pi/6) + 10
    ax2.fill(px, py, color=C["blue"] + "55")
    ax2.plot(px, py, color=C["blue"], linewidth=2.0)
    ax2.text(0, 10, f"G¹ module\n{BASE_S_M/6:.1f} m side\n~4,000 kg payload",
             ha="center", va="center", color=C["blue"], fontsize=7.5,
             fontweight="bold")

    ax2.set_title("Phase 01 Module vs Full G⁶ Crystal\n"
                  "(to scale — same hexagonal geometry)",
                  color=C["white"], fontsize=10)
    ax2.axis("off")

    fig.suptitle("Fig 5 — Lunar South Pole Site Analysis and Phase 01 Module",
                 fontsize=11, color=C["white"])
    fig.tight_layout()
    path = os.path.join(OUT, "fig5_lunar_site.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# Fig 6 — Earth / Moon / Mars comparative scaling
# ═══════════════════════════════════════════════════════════════════════════════
def fig6_planetary_scaling():
    fig, ax = plt.subplots(figsize=(10, 7))
    ax.set_facecolor(C["bg"])

    planet_data = [
        ("Earth",  9.810, C["blue"],   "●"),
        ("Moon",   1.625, C["dim"],    "▲"),
        ("Mars",   3.721, C["red"],    "■"),
    ]

    max_h = scaled_height(1.625)  # Moon height
    ax.set_xlim(-0.5, 3.5)
    ax.set_ylim(0, max_h * 1.15)

    for i, (name, g, color, marker) in enumerate(planet_data):
        h = scaled_height(g)
        s = scaled_base(g)
        x = i + 0.5

        # Tower silhouette (hexagonal prism schematic)
        w = s / 1000  # display width
        tower_w = max(0.12, w * 0.8)
        rect = mpatches.FancyBboxPatch(
            (x - tower_w/2, 0), tower_w, h,
            boxstyle="square,pad=0",
            facecolor=color + "33", edgecolor=color, linewidth=1.5
        )
        ax.add_patch(rect)

        # Height label
        ax.text(x, h + max_h * 0.02,
                f"{name}\ng = {g:.3f} m/s²\nh = {h/1000:.1f} km\nbase = {s:.0f} m",
                ha="center", va="bottom", color=color,
                fontsize=9, fontweight="bold")

        # γ annotation
        gamma = g / G_EARTH
        ax.text(x, h * 0.5,
                f"γ = {gamma:.3f}\nγ⁻¹ = {1/gamma:.2f}",
                ha="center", va="center", color=color + "cc",
                fontsize=8)

    # Tropopause lines
    tropos = {"Earth": 15_087.6, "Mars": 40_000, "Moon": float("inf")}
    for i, (name, g, color, _) in enumerate(planet_data):
        tp = tropos.get(name, None)
        if tp and tp < max_h * 1.1:
            ax.axhline(tp, xmin=(i+0.1)/3.5, xmax=(i+0.9)/3.5,
                       color=color, linewidth=1.0, linestyle="--", alpha=0.6)
            ax.text((i+0.5)/3.5 * 10 - 0.5 + 0.85, tp,
                    f"Tropopause\n{tp/1000:.0f} km",
                    color=color, fontsize=7, alpha=0.8)

    ax.set_ylabel("Structure height (m)", color=C["dim"])
    ax.set_xticks([])
    ax.set_title(
        "Fig 6 — G6 Crystal: Planetary Scaling\n"
        "Geometry preserved; all dimensions scale as g⊕/g_planet",
        pad=10, fontsize=11)
    ax.grid(True, axis="y", alpha=0.3)

    # Aspect ratio note
    ax.text(0.02, 0.98,
            f"Aspect ratio = {ASPECT:.0f} = {G6_INT}·τ = {G6_INT}·|μ_max|\n"
            f"preserved across all planetary scalings",
            transform=ax.transAxes, va="top", color=C["gold"],
            fontsize=8.5,
            bbox=dict(boxstyle="round,pad=0.3", facecolor=C["bg"],
                      edgecolor=C["border"]))

    fig.tight_layout()
    path = os.path.join(OUT, "fig6_planetary_scaling.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# Fig 7 — dm³ stability basin + NASA functional gap closure matrix
# ═══════════════════════════════════════════════════════════════════════════════
def fig7_stability_and_gaps():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 6.5))

    # ── Left: dm³ phase portrait ──────────────────────────────────────────────
    ax1.set_facecolor(C["bg"])
    ax1.set_aspect("equal")

    theta = np.linspace(0, 2*np.pi, 300)

    # Basin B1 (stable region, radius ~1)
    ax1.fill(np.cos(theta), np.sin(theta),
             color=C["green"] + "22", linewidth=0)
    ax1.plot(np.cos(theta), np.sin(theta),
             color=C["green"], linewidth=1.8, label="Basin B₁ (stable)")

    # Limit cycle Γ (radius 1 — normalised)
    ax1.plot(np.cos(theta), np.sin(theta),
             color=C["gold"], linewidth=2.5, linestyle="--",
             label="Limit cycle Γ")

    # Stability radius ε₀ = 1/3 around the cycle
    for r_offset in [1 - EPS0, 1 + EPS0]:
        ax1.plot(r_offset * np.cos(theta), r_offset * np.sin(theta),
                 color=C["violet"], linewidth=1.0, linestyle=":",
                 alpha=0.7)
    ax1.fill_between(
        (1 - EPS0) * np.cos(theta),
        (1 - EPS0) * np.sin(theta),
        (1 + EPS0) * np.cos(theta),
        color=C["violet"] + "22", linewidth=0,
        label=f"ε₀ = 1/3 stability band"
    )

    # Basin B2 (transition boundary)
    ax1.plot(1.6 * np.cos(theta), 1.6 * np.sin(theta),
             color=C["orange"], linewidth=1.0, linestyle="-.",
             alpha=0.6, label="Boundary B₂")

    # Basin B3 (collapse)
    ax1.plot(2.0 * np.cos(theta), 2.0 * np.sin(theta),
             color=C["red"], linewidth=0.8, linestyle="--",
             alpha=0.5, label="Collapse B₃")

    # Noise tolerance arc
    arc = Wedge((0,0), 1.0 + EPS0, 80, 100,
                color=C["violet"], alpha=0.3)
    ax1.add_patch(arc)
    ax1.annotate(f"τ·ε₀ = 2/3",
                 xy=(0, 1.33), xytext=(0.4, 1.6),
                 arrowprops=dict(arrowstyle="->", color=C["violet"]),
                 color=C["violet"], fontsize=8.5)

    # Tropopause analogue
    ax1.annotate("Tropopause\nanalogue",
                 xy=(0, 1.6), xytext=(-1.2, 1.8),
                 arrowprops=dict(arrowstyle="->", color=C["orange"]),
                 color=C["orange"], fontsize=8)

    ax1.set_xlim(-2.3, 2.3)
    ax1.set_ylim(-2.3, 2.3)
    ax1.set_xlabel("ρ (radial coordinate)")
    ax1.set_ylabel("θ (angular coordinate)")
    ax1.set_title("dm³ Phase Portrait\nStability basin and limit cycle Γ",
                  color=C["white"], fontsize=10)
    ax1.legend(loc="lower right", fontsize=7.5, framealpha=0.2,
               edgecolor=C["border"])

    # ── Right: NASA functional gap closure matrix ──────────────────────────────
    ax2.set_facecolor(C["panel"])
    ax2.axis("off")

    gaps = [
        ("FN-H-101L", "Pressurised habitat, short duration",      "G¹ hex module", "●"),
        ("FN-H-102L", "Pressurised habitat, month+",              "G³ cluster",    "●"),
        ("FN-P-101L", "Power generation, south pole",             "Passive resonance\nstability",  "◑"),
        ("FN-P-402L", "Power, year+ duration",                    "Arnold tongue\nlock",           "◑"),
        ("FN-L-101L", "Pressurised mating",                       "Hex interface\ngeometry",       "●"),
        ("FN-U-103L", "ISRU operations",                          "Material self-\nsufficiency",   "◑"),
        ("FN-T-201L", "Cargo transport to surface",               "Phased hex\npayload scaling",   "●"),
        ("FN-A-104L", "Robotic manipulation",                     "Colony.expand\n(Orthogenesis)", "◯"),
        ("FN-M-302L", "Surface mobility, sunlit",                 "Hex tile\ntraversability",      "◯"),
    ]

    col_labels = ["NASA Gap", "Description", "G6 Crystal\nResponse", "Status"]
    col_x      = [0.01, 0.18, 0.65, 0.93]
    row_h      = 0.083
    y0         = 0.97

    # Header
    for j, label in enumerate(col_labels):
        ax2.text(col_x[j], y0, label,
                 transform=ax2.transAxes,
                 va="top", ha="left",
                 fontsize=8.5, fontweight="bold",
                 color=C["gold"])

    ax2.axhline(y0 - 0.025, color=C["gold"],
                linewidth=0.8, transform=ax2.transAxes,
                xmin=0.0, xmax=1.0)

    status_color = {"●": C["green"], "◑": C["orange"], "◯": C["red"]}
    status_label = {"●": "Addressed",  "◑": "Partial",   "◯": "Open/sorry"}

    for i, (fid, desc, response, status) in enumerate(gaps):
        y = y0 - (i + 1) * row_h
        bg = C["bg"] if i % 2 == 0 else C["panel"]
        rect = mpatches.FancyBboxPatch(
            (0, y - 0.01), 1.0, row_h - 0.005,
            boxstyle="square,pad=0",
            transform=ax2.transAxes,
            facecolor=bg, edgecolor="none"
        )
        ax2.add_patch(rect)
        ax2.text(col_x[0], y + 0.025, fid,
                 transform=ax2.transAxes,
                 va="center", fontsize=7.2,
                 color=C["blue"], fontweight="bold")
        ax2.text(col_x[1], y + 0.025, desc,
                 transform=ax2.transAxes,
                 va="center", fontsize=7, color=C["white"])
        ax2.text(col_x[2], y + 0.025, response,
                 transform=ax2.transAxes,
                 va="center", fontsize=7, color=C["teal"])
        sc = status_color[status]
        ax2.text(col_x[3], y + 0.025, status,
                 transform=ax2.transAxes,
                 va="center", fontsize=11, color=sc)

    # Legend
    legend_y = y0 - (len(gaps) + 1.2) * row_h
    for sym, lbl in status_label.items():
        ax2.text(col_x[3] - 0.28, legend_y, f"{sym} {lbl}",
                 transform=ax2.transAxes,
                 va="center", fontsize=7.5,
                 color=status_color[sym])
        legend_y -= row_h * 0.7

    ax2.set_title("NASA Phase 01 Functional Gap Closure\n"
                  "(Moon Base User's Guide, NP-2026-04-6806-HQ)",
                  color=C["white"], fontsize=10, pad=8)

    fig.suptitle("Fig 7 — dm³ Stability Analysis and NASA Functional Gap Closure Matrix",
                 fontsize=11, color=C["white"])
    fig.tight_layout()
    path = os.path.join(OUT, "fig7_stability_gaps.pdf")
    fig.savefig(path)
    plt.close(fig)
    print(f"  saved {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# CSV data export
# ═══════════════════════════════════════════════════════════════════════════════
def export_csv():
    rows = []
    for name, info in PLANETS.items():
        g = info["g"]
        gamma = g / G_EARTH
        rows.append({
            "planet":     name,
            "g_ms2":      g,
            "gamma":      round(gamma, 4),
            "gamma_inv":  round(1/gamma, 4),
            "height_m":   round(scaled_height(g), 1),
            "height_km":  round(scaled_height(g)/1000, 2),
            "base_side_m": round(scaled_base(g), 2),
            "aspect_ratio": ASPECT,
            "layer_h_m":  round(scaled_height(g)/N_LAYERS, 1),
        })
    path = os.path.join(OUT, "g6_crystal_scaling.csv")
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)
    print(f"  saved {path}")

    # Schumann modes
    c = 3e8; R_e = 6.371e6
    schumann_rows = []
    for n in range(1, 8):
        fn = c / (2*np.pi*R_e) * np.sqrt(n*(n+1))
        schumann_rows.append({
            "n": n,
            "f_theoretical_Hz": round(fn, 4),
            "g6_match": "g6=33" if n == 4 else "",
            "pct_error": round(abs(33 - fn)/fn * 100, 3) if n == 4 else "",
        })
    path2 = os.path.join(OUT, "schumann_modes.csv")
    with open(path2, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=schumann_rows[0].keys())
        w.writeheader()
        w.writerows(schumann_rows)
    print(f"  saved {path2}")


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("G6 Crystal — generating all figures...")
    fig1_operator_hierarchy()
    fig2_hexagonal_geometry()
    fig3_arnold_tongue()
    fig4_structural_comparison()
    fig5_lunar_site()
    fig6_planetary_scaling()
    fig7_stability_and_gaps()
    export_csv()
    print("All done.")
