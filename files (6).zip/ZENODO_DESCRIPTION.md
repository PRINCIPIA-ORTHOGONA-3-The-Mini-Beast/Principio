# AutophagyDm3 — Zenodo Deposit Description

## Paste this into the Zenodo description field

---

**AutophagyDm3.lean** is a Lean 4/Mathlib4 formal verification file
supporting the chapter "Self-Regulation — Autophagy and the Triple-Alpha
Process as dm³ Generative Transitions" (Principia Orthogona, Book 3).

It proves **18 theorems without sorry** (zero actual sorry in any proof
term) covering four analytic pillars of the dm³ framework:

1. **Contact non-degeneracy** — the coefficient c(ρ) = −2ρ < 0 for ρ > 0,
   witnessing α ∧ dα ≠ 0 on the autophagy configuration manifold.

2. **Whitney A₁ fold at q = 1** — all four conditions for the fold
   potential V(q) = q³ − 3q: V′(1) = 0, V″(1) ≠ 0, V(1) = −2,
   and the double-root factorisation V(q) + 2 = (q−1)²(q+2).

3. **Gronwall stability radius** — ε₀ = 1/3, with basin asymmetry
   ε₀ < r* ≈ 4/5 verified by rational arithmetic.

4. **Stability functional** — Φ(ρ) = ρ² is strictly positive and
   strictly increasing for ρ > 0, modelling mTORC1 suppression cost.

Three open obligations (`contactForm_nondeg_full`,
`whitneyFold_from_kinase_data`, `limitCycle_exists_auto`) are stated
as `True := by trivial` stubs — tracked under AXLE Issue #14.
They represent genuine open problems (Mathlib differential forms,
Mather's theorem + kinase data, Poincaré–Bendixson), not gaps in the
argument.

**Related deposits:**
- DNLS companion (TribonacciDNLS.lean):
  https://doi.org/10.5281/zenodo.20026942
- Fruit-fly toy model (MultiOrbitBioSwarm.lean):
  https://doi.org/10.5281/zenodo.19210136
- AXLE repository: https://github.com/TOTOGT/AXLE

**Mathlib version:** v4.14.0 (pinned in lakefile.toml)  
**License:** MIT

---

## Suggested metadata

- **Title:** AutophagyDm3.lean — Lean 4 Formal Verification of dm³ Analytic Lemmas for Autophagy and Triple-Alpha Transitions
- **Resource type:** Software
- **Keywords:** Lean 4; Mathlib4; formal verification; autophagy; dm³; Whitney fold; contact geometry; Gronwall; mTORC1; TO/TOGT
- **Programming language:** Lean 4
- **License:** MIT
- **Related identifiers:**
  - `isPartOf` → https://github.com/TOTOGT/AXLE
  - `isRelatedTo` → 10.5281/zenodo.20026942 (DNLS paper)
  - `isRelatedTo` → 10.5281/zenodo.19210136 (fruit-fly paper)
  - `isSupplementTo` → [DOI of Book 3 / Mini-Beast chapter when published]
