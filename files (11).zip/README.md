# Biological Transitions as Multi-Agent Realisations of G = U∘F∘K∘C
### Version 2 — Complete
**Pablo Nogueira Grossi · May 2026**

**V2 DOI:** https://doi.org/10.5281/zenodo.20230612
**Concept DOI (all versions):** https://doi.org/10.5281/zenodo.19208015
**Series root:** https://doi.org/10.5281/zenodo.19117399
**GitHub / AXLE:** https://github.com/TOTOGT/AXLE
**Contact:** pgrossi888@outlook.com · g6llc@proton.me · ORCID: 0009-0000-6496-2186

---

## What this deposit contains

| File | Description |
|------|-------------|
| `multi_agent_togt_v2.pdf` | Complete V2 paper (13 pages, 4 figures) |
| `multi_agent_togt.tex` | LaTeX source |
| `multi_agent_togt.py` | Python simulation & figure generator |
| `MultiAgentTogt.lean` | Lean 4/Mathlib4 formal proofs (18 facts, 0 sorry) |
| `AutophagyDm3.lean` | Lean 4 proofs for Book 3 Chapters A & B (Issue #14 partial resolution) |
| `fig1_agent_trajectories.pdf` | N-agent convergence under G^6 |
| `fig2_pitchfork_scan.pdf` | HPA-axis saturated pitchfork bifurcation |
| `fig3_convergence.pdf` | Contraction rate across iterations |
| `fig4_operator_diagram.pdf` | Schematic of G = U o F o K o C pipeline |
| `pitchfork_scan.csv` | Raw data for fig2 |
| `fixed_point_theory (2).pdf` | Original V1 PDF (preserved) |

---

## What changed from V1 to V2

V1 (March 2026) contained only the 2-page skeleton PDF with stub sections.

V2 adds seven biological systems treated in full, each with named molecular
mechanisms, cell types, receptors, measured quantities, and published references:

- SS3  Drosophila connectome (139,255 neurons, FlyWire [8,13])
- SS4  HPA-axis stress response (CRH->ACTH->cortisol cascade [3,4])
- SS5  Circadian SCN (~20,000 neurons, VIP coupling [6,7])
- SS6  Immune affinity maturation (germinal centre, SHM at 10^-3/bp/division [10,12])
- SS7.1-7.2  Protein folding / prion bistability (Anfinsen, Whitney fold [9])
- SS7.3  Autophagy as dm3 fold -- Chapter A (Zenodo 10.5281/zenodo.20168812 [14])
- SS7.4  Polylaminin spinal cord repair -- Chapter B (6/8 patients, ANVISA Phase I [15,16])

Also added: four figures, LaTeX source, two Lean files, 18-entry reference list,
and companion citations (fruit-fly model Zenodo 10.5281/zenodo.20128568).

---

## Lean 4 formal verification

### MultiAgentTogt.lean -- 18 facts, 0 sorry

Covers theorems specific to this paper: pitchfork threshold arithmetic (T1-T3),
six-iterate bound (4/5)^6 < 27/100 (T4), dm3 normalisation (T6), compression
operator contraction (T7-T10), sub/super-threshold regimes (T11-T12), circadian
anchor T* = 2*pi > 6 (T15), immune fixed point (T16), contraction composition (T18).

### AutophagyDm3.lean -- 18 original theorems + Issue #14 update

All 18 original theorems remain proved without sorry. AXLE Issue #14 resolves:

Obligation 1 -- CLOSED:
  contactForm_nondeg_scalar and contactForm_orientation are real proved theorems.
  The contact form alpha = dz - rho^2 dtheta has non-zero coefficient
  c(rho) = -2*rho for all rho > 0.

Obligation 2 -- STRENGTHENED:
  whitneyFold_conditional is a proper conditional Prop: given that the mTORC1
  suppression map sigma is Morse at rho*, the Whitney A1 fold follows from
  V_factored. The sorry guards Mather's theorem only. V_is_morse_at_one proved.

Obligation 3 -- SPLIT:
  dm3_basin_compact and dm3_basin_nonempty proved (Gronwall annulus [1/3, 2]).
  omega_limit_nonempty and limitCycle_exists_auto remain stubs pending Mathlib
  semiflow definition and Poincare-Bendixson theorem.

~16 additional lemmas proved beyond the original 18, including basin_asymmetry
(1/3 < 4/5) and dPhi_at_threshold.

### Build
```
lake update && lake build MultiAgentTogt
lake update && lake build AutophagyDm3
```

---

## Building the paper

Prerequisites: pdflatex (TeX Live 2022+), python >= 3.10, numpy, matplotlib.

Generate figures:
```
python multi_agent_togt.py
```

Compile PDF:
```
pdflatex multi_agent_togt.tex
pdflatex multi_agent_togt.tex
```

---

## Series map

| Role | DOI / URL |
|------|-----------|
| Series root | 10.5281/zenodo.19117399 |
| Volume One (mathematics) | HAL hal-05555216v1 |
| Volume Two (contact geometry) | HAL hal-05559997v1 |
| This paper V2 | 10.5281/zenodo.20230612 |
| Companion Drosophila model v2 | 10.5281/zenodo.20128568 |
| Book 3 Chapter A (autophagy) | 10.5281/zenodo.20168812 |
| Book 3 Chapter B (polylaminin) | https://totogt.github.io/AXLE/a.PolyLaminin/chapter_B_polylaminin.html |

---

License: CC BY-NC-ND 4.0 -- Copyright (C) 2026 Pablo Nogueira Grossi / G6 LLC.
